function ProductSummary() {
  return <>ProductSummary</>;
}

export default ProductSummary;
